pip uninstall hfqco -y
python3 -m build
pip install  ~/pyHfqco/dist/hfqco-0.0.1-py3-none-any.whl   